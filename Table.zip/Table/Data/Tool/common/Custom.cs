﻿/*
 * 
 *  自定义的结构在这里申请
 * 
 */
using ProtoBuf;

namespace fs
{

}
