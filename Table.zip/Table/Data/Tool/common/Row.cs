﻿
namespace fs
{
    public abstract class Row<K>
    {
        public abstract K ID { get; }
    }
}
