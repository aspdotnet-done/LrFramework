﻿public interface ICustomType
{
    object Analyze(string str);
}
