﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class Game4 : Row<int>
    {

        /*
        序号
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        类别
(0-彩票，1-币，2弹药）
        */
        [ProtoMember(2)]
        public int Type { get; set; }

        /*
        奖励
        */
        [ProtoMember(3)]
        public int Award { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, Game4> Game4 { get; private set; }

    }
#endif
}
