﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class Std2 : Row<int>
    {

        /*
        id
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        2001
        */
        [ProtoMember(2)]
        public float key2001 { get; set; }

        /*
        2002
        */
        [ProtoMember(3)]
        public float key2002 { get; set; }

        /*
        2003
        */
        [ProtoMember(4)]
        public float key2003 { get; set; }

        /*
        2004
        */
        [ProtoMember(5)]
        public float key2004 { get; set; }

        /*
        2005
        */
        [ProtoMember(6)]
        public float key2005 { get; set; }

        /*
        2006
        */
        [ProtoMember(7)]
        public float key2006 { get; set; }

        /*
        2007
        */
        [ProtoMember(8)]
        public float key2007 { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, Std2> Std2 { get; private set; }

    }
#endif
}
