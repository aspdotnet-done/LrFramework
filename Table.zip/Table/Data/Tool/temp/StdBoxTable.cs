﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class StdBoxTable : Row<int>
    {

        /*
        序号
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        奖励
        */
        [ProtoMember(2)]
        public int reward { get; set; }

        /*
        进度条总量
        */
        [ProtoMember(3)]
        public float TotalPower { get; set; }

        /*
        进度衰减量（s）
        */
        [ProtoMember(4)]
        public float reduceSpeed { get; set; }

        /*
        按钮增加量
        */
        [ProtoMember(5)]
        public float AddPower { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, StdBoxTable> StdBoxTable { get; private set; }

    }
#endif
}
