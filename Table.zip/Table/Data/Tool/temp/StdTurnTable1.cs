﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class StdTurnTable1 : Row<int>
    {

        /*
        转盘格数
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        奖励类型
        */
        [ProtoMember(2)]
        public string type { get; set; }

        /*
        类型名字
        */
        [ProtoMember(3)]
        public string type_name { get; set; }

        /*
        参数值
        */
        [ProtoMember(4)]
        public int value { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, StdTurnTable1> StdTurnTable1 { get; private set; }

    }
#endif
}
