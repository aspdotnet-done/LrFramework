﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class StdBallLottery : Row<int>
    {

        /*
        币类型
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        保底彩票
        */
        [ProtoMember(2)]
        public int lottery { get; set; }

        /*
        额外彩票
        */
        [ProtoMember(3)]
        public int extra_lottery { get; set; }

        /*
        备注
        */
        [ProtoMember(4)]
        public string desc { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, StdBallLottery> StdBallLottery { get; private set; }

    }
#endif
}
