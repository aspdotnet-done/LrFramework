﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class Std3 : Row<int>
    {

        /*
        id
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        1
        */
        [ProtoMember(2)]
        public int key1 { get; set; }

        /*
        2
        */
        [ProtoMember(3)]
        public int key2 { get; set; }

        /*
        3
        */
        [ProtoMember(4)]
        public int key3 { get; set; }

        /*
        4
        */
        [ProtoMember(5)]
        public int key4 { get; set; }

        /*
        5
        */
        [ProtoMember(6)]
        public int key5 { get; set; }

        /*
        6
        */
        [ProtoMember(7)]
        public int key6 { get; set; }

        /*
        7
        */
        [ProtoMember(8)]
        public int key7 { get; set; }

        /*
        8
        */
        [ProtoMember(9)]
        public int key8 { get; set; }

        /*
        9
        */
        [ProtoMember(10)]
        public int key9 { get; set; }

        /*
        10
        */
        [ProtoMember(11)]
        public int key10 { get; set; }

        /*
        11
        */
        [ProtoMember(12)]
        public int key11 { get; set; }

        /*
        12
        */
        [ProtoMember(13)]
        public int key12 { get; set; }

        /*
        13
        */
        [ProtoMember(14)]
        public int key13 { get; set; }

        /*
        14
        */
        [ProtoMember(15)]
        public int key14 { get; set; }

        /*
        15
        */
        [ProtoMember(16)]
        public int key15 { get; set; }

        /*
        16
        */
        [ProtoMember(17)]
        public int key16 { get; set; }

        /*
        17
        */
        [ProtoMember(18)]
        public int key17 { get; set; }

        /*
        18
        */
        [ProtoMember(19)]
        public int key18 { get; set; }

        /*
        19
        */
        [ProtoMember(20)]
        public int key19 { get; set; }

        /*
        20
        */
        [ProtoMember(21)]
        public int key20 { get; set; }

        /*
        21
        */
        [ProtoMember(22)]
        public int key21 { get; set; }

        /*
        22
        */
        [ProtoMember(23)]
        public int key22 { get; set; }

        /*
        23
        */
        [ProtoMember(24)]
        public int key23 { get; set; }

        /*
        24
        */
        [ProtoMember(25)]
        public int key24 { get; set; }

        /*
        25
        */
        [ProtoMember(26)]
        public int key25 { get; set; }

        /*
        26
        */
        [ProtoMember(27)]
        public int key26 { get; set; }

        /*
        27
        */
        [ProtoMember(28)]
        public int key27 { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, Std3> Std3 { get; private set; }

    }
#endif
}
