﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class High : Row<int>
    {

        /*
        序号
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        随机奖励类型权重
        */
        [ProtoMember(2)]
        public int[] odds { get; set; }

        /*
        奖励数值
        */
        [ProtoMember(3)]
        public int[] nums { get; set; }

        /*
        宝箱奖励类型权重
        */
        [ProtoMember(4)]
        public int[] boxOdds { get; set; }

        /*
        宝箱奖励数值
        */
        [ProtoMember(5)]
        public int[] boxNums { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, High> High { get; private set; }

    }
#endif
}
