﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class SpecAward : Row<int>
    {

        /*
        序号
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        奖励数值
        */
        [ProtoMember(2)]
        public int num { get; set; }

        /*
        每次叠加
        */
        [ProtoMember(3)]
        public int add { get; set; }

        /*
        叠加最大值
        */
        [ProtoMember(4)]
        public int max { get; set; }

        /*
        最大最小范围
        */
        [ProtoMember(5)]
        public int[] range { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, SpecAward> SpecAward { get; private set; }

    }
#endif
}
