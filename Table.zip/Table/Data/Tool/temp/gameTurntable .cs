﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class gameTurntable  : Row<int>
    {

        /*
        序号
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        奖励类型
（1-彩票，2-游戏币，3-推盘奖励币，4-小游戏A，5-小游戏B）
        */
        [ProtoMember(2)]
        public int type { get; set; }

        /*
        奖励数值
        */
        [ProtoMember(3)]
        public int num { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, gameTurntable > gameTurntable  { get; private set; }

    }
#endif
}
