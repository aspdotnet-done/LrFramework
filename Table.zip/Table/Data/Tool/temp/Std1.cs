﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class Std1 : Row<int>
    {

        /*
        ID
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        币票率
        */
        [ProtoMember(2)]
        public string TestString { get; set; }

        /*
        1
        */
        [ProtoMember(3)]
        public int key1 { get; set; }

        /*
        2
        */
        [ProtoMember(4)]
        public int key2 { get; set; }

        /*
        3
        */
        [ProtoMember(5)]
        public int key3 { get; set; }

        /*
        4
        */
        [ProtoMember(6)]
        public int key4 { get; set; }

        /*
        5
        */
        [ProtoMember(7)]
        public int key5 { get; set; }

        /*
        6
        */
        [ProtoMember(8)]
        public int key6 { get; set; }

        /*
        7
        */
        [ProtoMember(9)]
        public int key7 { get; set; }

        /*
        8
        */
        [ProtoMember(10)]
        public int key8 { get; set; }

        /*
        9
        */
        [ProtoMember(11)]
        public int key9 { get; set; }

        /*
        10
        */
        [ProtoMember(12)]
        public int key10 { get; set; }

        /*
        15
        */
        [ProtoMember(13)]
        public int key15 { get; set; }

        /*
        20
        */
        [ProtoMember(14)]
        public int key20 { get; set; }

        /*
        25
        */
        [ProtoMember(15)]
        public int key25 { get; set; }

        /*
        30
        */
        [ProtoMember(16)]
        public int key30 { get; set; }

        /*
        35
        */
        [ProtoMember(17)]
        public int key35 { get; set; }

        /*
        40
        */
        [ProtoMember(18)]
        public int key40 { get; set; }

        /*
        45
        */
        [ProtoMember(19)]
        public int key45 { get; set; }

        /*
        50
        */
        [ProtoMember(20)]
        public int key50 { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, Std1> Std1 { get; private set; }

    }
#endif
}
