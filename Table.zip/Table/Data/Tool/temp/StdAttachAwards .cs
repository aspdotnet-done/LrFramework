﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class StdAttachAwards  : Row<string>
    {

        /*
        ID名字
        */
        [ProtoMember(1)]
        public string id { get; set; }

        /*
        提示信息
        */
        [ProtoMember(2)]
        public string type { get; set; }

        /*
        参数值
        */
        [ProtoMember(3)]
        public int value { get; set; }

        public override string ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<string, StdAttachAwards > StdAttachAwards  { get; private set; }

    }
#endif
}
