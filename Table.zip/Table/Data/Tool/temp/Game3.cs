﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class Game3 : Row<int>
    {

        /*
        序号
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        时间
        */
        [ProtoMember(2)]
        public int Timer { get; set; }

        /*
        血量
        */
        [ProtoMember(3)]
        public int[] Hps { get; set; }

        /*
        奖励
        */
        [ProtoMember(4)]
        public int[] Awards { get; set; }

        /*
        弹药
        */
        [ProtoMember(5)]
        public int Bullet { get; set; }

        /*
        通关
        */
        [ProtoMember(6)]
        public int Pass { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, Game3> Game3 { get; private set; }

    }
#endif
}
