﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class jpTurntable  : Row<int>
    {

        /*
        序号
        */
        [ProtoMember(1)]
        public int id { get; set; }

        /*
        奖励类型
（1-彩票，2-游戏币，3-推盘奖励币，4-JP机会）
        */
        [ProtoMember(2)]
        public int type { get; set; }

        /*
        奖励数值
        */
        [ProtoMember(3)]
        public int num { get; set; }

        /*
        抽中权重
        */
        [ProtoMember(4)]
        public int percent { get; set; }

        public override int ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<int, jpTurntable > jpTurntable  { get; private set; }

    }
#endif
}
