﻿
using ProtoBuf;

namespace fs
{
    [ProtoContract]
    public class StdBonus : Row<string>
    {

        /*
        ID名字
        */
        [ProtoMember(1)]
        public string id { get; set; }

        /*
        提示名字
        */
        [ProtoMember(2)]
        public string name { get; set; }

        /*
        参数值
        */
        [ProtoMember(3)]
        public int[] value { get; set; }

        public override string ID{ get { return id; } }
    }

#if UNITY_2017_1_OR_NEWER
    public partial class TableLib
    {

        public static Table<string, StdBonus> StdBonus { get; private set; }

    }
#endif
}
